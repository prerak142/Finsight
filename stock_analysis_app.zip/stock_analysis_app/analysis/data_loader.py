import os
import pandas as pd
import json

# Folder structure
FINANCIAL_DATA_DIR = os.path.join("data", "financial_data")
NEWS_DATA_DIR = os.path.join("data", "news_data")

def load_price_data(ticker):
    """
    Loads financial CSV data for the given stock ticker.
    Returns a pandas DataFrame with tz-naive datetime index.
    """
    filepath = os.path.join(FINANCIAL_DATA_DIR, f"{ticker}_financials.csv")
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"No financial data found for {ticker} at {filepath}")

    df = pd.read_csv(filepath, skiprows=3, parse_dates=["Date"])

    # Force remove timezone from 'Date' column if present
    df["Date"] = pd.to_datetime(df["Date"], utc=True).dt.tz_convert(None)

    # Set index and ensure it's tz-naive too
    df.set_index("Date", inplace=True)
    df.index = pd.to_datetime(df.index).tz_localize(None)

    df.sort_index(inplace=True)
    return df


def load_news_data(ticker):
    """
    Loads news articles for the given ticker from JSON file.
    Returns a list of valid news dictionaries.
    """
    filepath = os.path.join(NEWS_DATA_DIR, f"{ticker}.json")
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"No news data found for {ticker} at {filepath}")

    with open(filepath, "r", encoding="utf-8") as f:
        articles = json.load(f)

    # Filter only articles that have sentiment scores
    valid_articles = [a for a in articles if "sentiment" in a and isinstance(a["sentiment"], (int, float))]
    return valid_articles

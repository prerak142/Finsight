import streamlit as st
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from io import BytesIO
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from export.pdf_exporter import export_to_pdf
# Note: You need to provide implementations for these imports or replace them
from analysis import data_loader, sentiment, indicators, gemini_wrapper
from models.sarima_forecaster import forecast_prices

# Streamlit Config
st.set_page_config(page_title="AI Stock Advisor", layout="wide")
st.title("AI-Powered Stock Analysis Dashboard")

# Sidebar Input
with st.sidebar:
    st.header("Input Settings")
    tickers = st.text_input("Enter up to 4 tickers (comma-separated):", "AAPL, MSFT, META").upper()
    selected = [t.strip() for t in tickers.split(",") if t.strip()]
    if len(selected) > 4:
        st.warning("Max 4 tickers allowed.")
        st.stop()

    profile = st.selectbox("Select Risk Profile", ["Low", "Moderate", "High"])
    horizon = st.selectbox("Investment Horizon", ["Short Term", "Long Term"])
    run = st.button("Run Analysis")

# Sentiment Series Function
_analyzer = SentimentIntensityAnalyzer()

def sentiment_time_series(articles):
    dated_scores = []
    for article in articles:
        date = article.get("publishedAt") or article.get("date")
        text = f"{article.get('title', '')} {article.get('description', '')}"
        if date and text.strip():
            try:
                parsed_date = pd.to_datetime(date)
                score = _analyzer.polarity_scores(text)["compound"]
                dated_scores.append((parsed_date.date(), score))
            except Exception:
                continue
    if not dated_scores:
        raise ValueError("No valid dated sentiment entries.")
    df = pd.DataFrame(dated_scores, columns=["date", "score"])
    return df.groupby("date")["score"].mean()

# Main App Logic
if run:
    st.info("Fetching and analyzing data...")

    stocks = {}
    dfs = {}
    forecast_dict = {}
    sentiments = {}

    for t in selected:
        try:
            df = data_loader.load_price_data(t)
            news = data_loader.load_news_data(t)
            df, vol, sharpe = indicators.compute_indicators(df)
            senti = sentiment.avg_sentiment(news)

            forecast, _ = forecast_prices(df, t)
            forecast_dict[t] = {"forecast": forecast}

            stocks[t] = {
                "return": df["Return"].mean() * 252,
                "volatility": vol,
                "sharpe": sharpe,
                "sentiment": senti,
                "macd": df["MACD"].iloc[-1],
                "rsi": df["RSI"].iloc[-1],
                "expected_return": forecast.iloc[-1] / df["Close"].iloc[-1] - 1
            }

            dfs[t] = df

            try:
                senti_series = sentiment_time_series(news)
                sentiments[t] = senti_series
            except Exception as e:
                st.warning(f"No sentiment time-series for {t}: {e}")

        except Exception as e:
            st.error(f"Error processing {t}: {e}")

    if not stocks:
        st.warning("No valid data to analyze.")
        st.stop()

    # Display Data
    dfm = pd.DataFrame(stocks).T
    st.subheader("Stock Metrics Comparison")
    st.dataframe(dfm.style.format("{:.2f}"), use_container_width=True)

    st.markdown("### Visual Comparison of Key Metrics")
    fig, ax = plt.subplots(figsize=(10, 5))
    dfm[["return", "volatility", "sharpe", "sentiment", "macd", "rsi"]].plot(kind='bar', ax=ax)
    plt.title("Stock Metrics Overview")
    plt.ylabel("Value")
    plt.xticks(rotation=0)
    st.pyplot(fig)

    st.markdown("### Forecasted Price Trends (SARIMA)")
    for t in selected:
        if t in forecast_dict:
            st.markdown(f"#### {t} Forecast")
            fig, ax = plt.subplots()
            dfs[t]["Close"].plot(ax=ax, label="Historical")
            forecast_dict[t]["forecast"].plot(ax=ax, label="Forecast", color='green')
            plt.title(f"{t} - SARIMA Forecast")
            plt.legend()
            st.pyplot(fig)

    st.markdown("### Technical Indicators (RSI & MACD)")
    for t in dfs:
        st.markdown(f"#### {t}")
        col1, col2 = st.columns(2)
        with col1:
            st.line_chart(dfs[t]["RSI"].dropna(), height=200)
        with col2:
            st.line_chart(dfs[t]["MACD"].dropna(), height=200)

    st.markdown("### Sentiment Over Time")
    for t in sentiments:
        st.markdown(f"#### {t}")
        st.line_chart(sentiments[t])

    st.markdown("### Investment Summary")
    full_summary = gemini_wrapper.generate_report(stocks, profile, horizon)
    st.text_area("AI-Generated Investment Advice", full_summary, height=400)

    # Export to PDF
    st.markdown("---")
    # Debug input data
    st.write(f"dfm: {dfm is not None}")
    st.write(f"full_summary: {len(full_summary) if full_summary else 'Empty'}")
    st.write(f"dfs: {list(dfs.keys()) if dfs else 'None'}")
    st.write(f"forecast_dict: {list(forecast_dict.keys()) if forecast_dict else 'None'}")
    st.write(f"sentiments: {list(sentiments.keys()) if sentiments else 'None'}")

    if st.button("Export Report to PDF", key="export_pdf_button"):
        try:
            pdf_data = export_to_pdf(
                df=dfm,
                summary=full_summary,
                dfs=dfs,
                forecasts=forecast_dict,
                sentiments=sentiments
            )
            st.session_state['pdf_data'] = pdf_data.getvalue()
            st.session_state['pdf_ready'] = True
        except Exception as e:
            st.error(f"Failed to generate PDF: {e}")

    if st.session_state.get('pdf_ready', False):
        st.download_button(
            label="Click to Download Report",
            data=st.session_state['pdf_data'],
            file_name="stock_report.pdf",
            mime="application/pdf",
            key="pdf_download_button"
        )
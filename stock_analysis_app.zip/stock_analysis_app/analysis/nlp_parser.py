import spacy

nlp = spacy.load("en_core_web_sm")

def parse_investment_query(text):
    doc = nlp(text.lower())
    result = {
        "risk": "moderate",
        "duration": "long term",
        "sectors": "technology"
    }

    if "short" in text and "term" in text:
        result["duration"] = "short term"
    elif "long" in text and "term" in text:
        result["duration"] = "long term"

    if "high risk" in text:
        result["risk"] = "high"
    elif "low risk" in text:
        result["risk"] = "low"

    sectors = []
    for token in doc:
        if token.text in ["tech", "energy", "finance", "health", "pharma"]:
            sectors.append(token.text)

    if sectors:
        result["sectors"] = ", ".join(set(sectors))

    return result

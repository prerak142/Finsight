import matplotlib.pyplot as plt
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX

def plot_forecast(series, ticker="TICKER"):
    series = series.dropna().astype(float)
    model = SARIMAX(series, order=(1,1,1), seasonal_order=(1,1,0,12))
    results = model.fit(disp=False)

    forecast = results.get_forecast(steps=30)
    pred = forecast.predicted_mean
    conf_int = forecast.conf_int()

    fig, ax = plt.subplots(figsize=(8, 3))
    series[-90:].plot(ax=ax, label="Historical")
    pred.plot(ax=ax, label="Forecast", color="green")
    ax.fill_between(pred.index, conf_int.iloc[:, 0], conf_int.iloc[:, 1], color="gray", alpha=0.3)
    ax.set_title(f"{ticker} - 30 Day Forecast")
    ax.legend()
    return fig

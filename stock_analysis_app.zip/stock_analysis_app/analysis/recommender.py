def rank(stocks):
    scores = {}
    for t, data in stocks.items():
        # Sample scoring: positive sentiment + return - volatility
        score = (
            data["return"] * 0.4 +
            data["sharpe"] * 0.3 +
            data["sentiment"] * 0.2 -
            data["volatility"] * 0.1
        )
        scores[t] = score
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)

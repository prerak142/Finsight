import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

_analyzer = SentimentIntensityAnalyzer()
def avg_sentiment(articles):
    """
    Computes the average sentiment score across all articles.
    """
    scores = []
    for article in articles:
        text = f"{article.get('title', '')} {article.get('description', '')}"
        if text.strip():
            score = _analyzer.polarity_scores(text)["compound"]
            scores.append(score)

    return sum(scores) / len(scores) if scores else 0.0

def sentiment_time_series(articles):
    """
    Given a list of news articles with 'publishedAt', 'title', and 'description',
    return a pandas Series of average daily sentiment scores.
    """
    dated_scores = []

    for article in articles:
        date = article.get("publishedAt") or article.get("date")
        text = f"{article.get('title', '')} {article.get('description', '')}"
        if date and text.strip():
            try:
                parsed_date = pd.to_datetime(date)
                score = _analyzer.polarity_scores(text)["compound"]
                dated_scores.append((parsed_date.date(), score))
            except Exception:
                continue

    if not dated_scores:
        raise ValueError("No valid dated sentiment entries.")

    df = pd.DataFrame(dated_scores, columns=["date", "score"])
    return df.groupby("date")["score"].mean()

import pandas as pd
import numpy as np

def compute_indicators(df):
    df = df.copy()

    # Daily returns
    df["Return"] = df["Close"].pct_change()

    # Volatility and Sharpe Ratio
    volatility = df["Return"].std() * np.sqrt(252)
    sharpe = df["Return"].mean() / df["Return"].std() * np.sqrt(252) if df["Return"].std() != 0 else 0

    # --- RSI ---
    delta = df["Close"].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)

    avg_gain = gain.rolling(window=14, min_periods=14).mean()
    avg_loss = loss.rolling(window=14, min_periods=14).mean()
    rs = avg_gain / avg_loss
    df["RSI"] = 100 - (100 / (1 + rs))

    # --- MACD ---
    ema12 = df["Close"].ewm(span=12, adjust=False).mean()
    ema26 = df["Close"].ewm(span=26, adjust=False).mean()
    df["MACD"] = ema12 - ema26

    df.dropna(inplace=True)
    return df, volatility, sharpe

import os
from dotenv import load_dotenv
from typing import Dict
import google.generativeai as genai
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb import PersistentClient

# Load Gemini API Key
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")

# Configure Gemini model
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel(model_name="gemini-1.5-pro-latest")

# Vector Store and Embedder
client = PersistentClient(path="data/vector_store")
_collection = client.get_or_create_collection("news")
_embedder = SentenceTransformer("all-MiniLM-L6-v2")


def query_news(ticker: str, k: int = 3) -> str:
    """
    Query the ChromaDB vector store to retrieve relevant news for a ticker.
    """
    try:
        embedding = _embedder.encode(ticker).tolist()
        results = _collection.query(query_embeddings=[embedding], n_results=k)
        docs = results.get("documents", [[]])[0]
        return "\n".join(docs)
    except Exception as e:
        print(f"[Chroma Query Error] {ticker}: {e}")
        return "No relevant news context available."


def generate_report(stocks: Dict[str, Dict], profile="Moderate", horizon="Long Term") -> str:
    """
    Generates a detailed investment report using Gemini API.
    Falls back to structured rule-based summary if Gemini fails.
    """

    # Gemini Prompt Construction
    prompt = f"""
You are an expert investment advisor.

Generate a detailed, professional, and structured stock investment summary based on the following:

Investor Profile: Risk Tolerance = {profile}, Investment Horizon = {horizon}

For each ticker, include:
1. Performance insights
2. Sentiment interpretation
3. RSI & MACD explanation
4. Short-term recommendation
5. Long-term recommendation

Finally, summarize:
- Which stocks are good for short-term vs long-term investments
- Which stocks to avoid or monitor

Avoid any emojis or disclaimers.

---

Metrics and News:
"""

    # Fallback Setup
    fallback_report = [f"# AI-Powered Investment Analysis Report\n"]
    fallback_report.append(f"Investor Profile: {profile} Risk Tolerance")
    fallback_report.append(f"Investment Horizon: {horizon}")
    fallback_report.append("-" * 50)

    short_term_buys = []
    long_term_buys = []

    for ticker, metrics in stocks.items():
        ret = metrics["return"]
        vol = metrics["volatility"]
        sharpe = metrics["sharpe"]
        senti = metrics["sentiment"]
        rsi = metrics["rsi"]
        macd = metrics["macd"]
        expected = metrics.get("expected_return", 0)

        # Query relevant news
        news = query_news(ticker)

        prompt += f"""
Ticker: {ticker}
Return: {ret:.2f}%
Volatility: {vol:.2f}
Sharpe: {sharpe:.2f}
Sentiment: {senti:.2f}
MACD: {macd:.2f}
RSI: {rsi:.2f}
Expected Return (SARIMA): {expected:.2f}
News: {news}
"""

        # --- Rule-based fallback summary ---
        # Short-Term Logic
        if rsi > 70:
            short_term = "Overbought - Potential sell or wait"
        elif rsi < 30:
            short_term = "Oversold - Attractive for short-term buy"
            short_term_buys.append(ticker)
        else:
            short_term = "Neutral - No strong signal"

        # Long-Term Logic
        if sharpe > 0.4 and senti > 0:
            long_term = "Good long-term investment"
            long_term_buys.append(ticker)
        elif sharpe < 0:
            long_term = "Risky for long-term holding"
        else:
            long_term = "Hold or monitor further"

        summary = f"""
### {ticker}
- Annual Return: {ret:.2f}%
- Volatility: {vol:.2f}
- Sharpe Ratio: {sharpe:.2f}
- Sentiment Score: {senti:.2f}
- RSI: {rsi:.2f}
- MACD: {macd:.2f}
- Expected Return (SARIMA): {expected:.2f}

Short-Term Outlook: {short_term}
Long-Term Outlook: {long_term}
"""
        fallback_report.append(summary.strip())

    fallback_report.append("\n---")
    fallback_report.append("## Final Summary & Recommendations")
    fallback_report.append(f"Short-Term Picks: {', '.join(short_term_buys) if short_term_buys else 'None'}")
    fallback_report.append(f"Long-Term Picks: {', '.join(long_term_buys) if long_term_buys else 'None'}")

    # --- Call Gemini ---
    try:
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        print(f"[Gemini Error]: {e}")
        return "\n".join(fallback_report)
